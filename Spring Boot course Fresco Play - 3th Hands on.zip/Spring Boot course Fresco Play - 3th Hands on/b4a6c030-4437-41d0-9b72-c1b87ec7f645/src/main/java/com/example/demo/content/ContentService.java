package com.example.demo.content;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class ContentService {
	

	private List<Course> AIcourses = new ArrayList<>(Arrays.asList(
			
			new Course(2001, "MFDM™ AI - The Renaissance", 60, 120, 200),
			new Course(2002, "SageMaker - Amazon ML", 180, 100, 200),
			new Course(2003, "Watson - AI on IBM Cloud", 100, 100, 200)
			
			));
	
	
	private List<Course> BCcourses = new ArrayList<>(Arrays.asList(
			
			new Course(3001, "Blockchain - Potentes Nexus", 150, 150, 300),
			new Course(3002, "Blockchain Intermedio", 100, 150, 300),
			new Course(3003, "Hyperledger Fabric", 120, 100, 300)
			
			));
	
	
	private List<Course> CCcourses = new ArrayList<>(Arrays.asList(
			
			new Course(4001, "Cloud Computing", 60, 100, 400),
			new Course(4002, "Computação em nuvem", 180, 100, 400),
			new Course(4003, "Serverless", 150, 100, 400)
			
			));

	
	private List<Category> categories = new ArrayList<>(Arrays.asList(
			
			new Category(200, "Artificial Inteligence", "Artificial Intelligence (AI) is a technology used in "
					+ "the computer science field, where the computers are trained to think and take decisions like "
					+ "human brains, but in a creative manner.", AIcourses), 
			
			new Category(300, "Block Chain", "Blockchain can serve as an open, distributed ledger that can record "
					+ "transactions between two parties efficiently and in a verifiable and permanent way.", BCcourses),
			
			new Category(400, "Cloud Computing", "The practice of using a network of remote servers hosted on the Internet "
					+ "to store, manage, and process data, rather than a local server or a personal computer.", CCcourses)
			
			));


/****************************************** S E R V I C E ' S   M E T H O D S *************************************/

    //put your code here.
	public List<Category> getAllContent() {
		return categories;
	
	}
	
	
	
}
