package com.example.demo.employee;

import java.util.Collections;
import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
		
	private List<Employee> employees = new ArrayList<>(Arrays.asList(
			
			new Employee("Tim", 32, 7),
			new Employee("Anil", 22, 3),
			new Employee("Kumar", 30, 6),
			new Employee("Kemp", 24, 2),
			new Employee("Sandhya", 20, 0)
					
	));
	
	
	public int[] getEmployees() {

		int[] Ages = {0,0,0,0,0};
		
		ordering();
		
		for(int i = 0; i < employees.size(); i++) {
			
			Ages[i] = employees.get(i).getAge();			
			
			//System.out.println(employees.get(i).getAge());
		}

		return Ages;
    }
	
	
	public void ordering() {
		
		Collections.sort(employees);
	}
	
}
